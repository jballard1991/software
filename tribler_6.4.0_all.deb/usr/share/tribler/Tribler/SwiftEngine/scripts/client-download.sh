./swift -t 127.0.0.1:6778 -h e5a12c7ad2d8fab33c699d1e198d66f79fa610c3 -k -p

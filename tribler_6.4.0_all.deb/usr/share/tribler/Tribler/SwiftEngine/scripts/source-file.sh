./swift -i bunny.ogg -f storage.dat -l 0.0.0.0:6778

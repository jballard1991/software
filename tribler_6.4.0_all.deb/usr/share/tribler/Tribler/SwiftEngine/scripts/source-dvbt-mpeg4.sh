./scripts/transcode-mpeg4.sh | ./swift -i - -f storage.dat -l 0.0.0.0:6778

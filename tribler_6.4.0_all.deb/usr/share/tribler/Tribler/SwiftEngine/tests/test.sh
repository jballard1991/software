#!/bin/sh
addrtest
apitest
bin64test
binfragtest
binstest2
binstest3
binstest4
chunkaddrtest
dgramtest
freemap
hashtest
transfertest
python activatetest.py
python cmdgwtest.py
python havetest.py
python httpmftest.py
python livetest.py
python livetest2.py
python pexreqtest.py
python pexrestest.py
python requesttest.py
python statsgwtest.py
python test_tunnel.py
python vodmftest.py
python vodtest.py

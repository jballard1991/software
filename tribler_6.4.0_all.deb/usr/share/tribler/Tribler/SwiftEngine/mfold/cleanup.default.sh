#!/bin/bash

killall -q leecher || true

killall seeder || true

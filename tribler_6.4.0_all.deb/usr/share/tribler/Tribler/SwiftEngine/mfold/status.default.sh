echo -e $HOST"\t"`tail -1 swift/$HOST-lerr`
